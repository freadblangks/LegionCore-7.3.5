UPDATE race_unlock_requirement SET expansion=6, achievementId=12244 WHERE raceID=27;
UPDATE race_unlock_requirement SET expansion=6, achievementId=12245 WHERE raceID=28;
UPDATE race_unlock_requirement SET expansion=6, achievementId=12242 WHERE raceID=29;
UPDATE race_unlock_requirement SET expansion=6, achievementId=12243 WHERE raceID=30;
